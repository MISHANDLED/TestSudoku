//
//  ViewController.swift
//  SudokuApp
//
//  Created by Devansh Mohata on 07/05/24.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var textField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func onClick(_ sender: UIButton) {
        if let value = textField.text,
           let val = Int(value) {
            if val < 50 {
                let vc = SudokuMain()
                vc.noOfCells = val
                navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
}
